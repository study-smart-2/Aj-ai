# AJ Android Assistant

This build uses the uploaded PriyaAI project as its base and renames the user-facing assistant to AJ. It retains its Gemini Live voice conversation, speech input/output, memory, camera input, app-launch and accessibility actions.

## Bluetooth audio
AJ requests Android communication audio routing and prefers a connected Bluetooth headset (BLE headset or Bluetooth SCO) when Android exposes it. Pair/connect the headset in Android Bluetooth settings before starting AJ. Android may keep media-only A2DP devices outside the communication-device list; on those devices output routing remains controlled by Android. Android 12+ may request Nearby devices/Bluetooth Connect permission.

## Build APK on GitHub
Upload the contents of this folder to the repository root, preserving `.github/workflows/android.yml`. Open Actions, run **Build AJ APK**, then download the `AJ-debug-apk` artifact.

## Notes
- Application ID: `com.aj.ai`. This installs as a separate app from the old PriyaAI package.
- Gemini Live requires a valid Gemini API key in the app settings. API/model availability depends on Google's current service access.
- Accessibility actions require the user to enable AJ's Accessibility Service in Android Settings. They are not a bypass for secure folders, app locks, or Android profile isolation.
- Bluetooth routing is best-effort and depends on device firmware and Android audio policy.
- Source has not been compiled or tested on a physical phone in this environment. GitHub Actions will provide the actual build result.

## AJ Manager engine modules included
The source also includes AJ Manager AI provider adapters, encrypted key-store helper, action-plan parser/executor, Telegram workflow definitions, advanced Accessibility Service, and screen-capture/OCR service. These modules are included in the APK source tree as reusable components. The current launch screen still uses the reference project's Gemini Live conversation flow; the advanced task-planner and OCR flows are not yet fully connected to the launch-screen controls.


## AJ v1.3 — Screen Control + Screen Reading

1. Install the APK and open AJ → Menu → Permissions.
2. Open Android Accessibility settings and enable **AJ advanced screen control** (not only the legacy Priya Accessibility entry).
3. Return to AJ. The permissions page shows whether the AJ service is actually connected.
4. Tap **Enable Screen OCR** and approve Android's screen-capture prompt. This is optional; accessibility text reading and taps work without OCR on apps that expose accessible UI nodes.
5. Start AJ and ask it to read the current screen, tap a visible label, type into the focused field, or scroll.

Android will show its screen-capture foreground notification while OCR capture is active. Stop it from the same Permissions page. Some protected apps/screens intentionally block capture, and some custom-drawn UI elements may not expose accessible text. Text entry does not press Send/Submit automatically.

This source package has not been compiled or device-tested in this environment. Build it through the included GitHub Actions workflow and test on the target phone.
