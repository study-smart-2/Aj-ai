package com.priya.ai

import android.annotation.SuppressLint
import android.content.Context
import android.content.Intent
import android.media.*
import android.os.Build
import android.media.audiofx.AcousticEchoCanceler
import android.media.audiofx.NoiseSuppressor
import android.os.Handler
import android.os.Looper
import android.provider.ContactsContract
import com.ajmanager.ai.control.AJAccessibilityService
import com.ajmanager.ai.control.PlannedAction
import com.ajmanager.ai.screen.ScreenFrameStore
import android.util.Base64
import okhttp3.*
import okio.ByteString
import org.json.JSONArray
import org.json.JSONObject
import java.util.concurrent.Executors
import java.util.concurrent.TimeUnit

@SuppressLint("MissingPermission")
class GeminiLive(private val ctx: Context) {
    private val client = OkHttpClient.Builder().pingInterval(20, TimeUnit.SECONDS).build()
    private val main = Handler(Looper.getMainLooper())
    private val playExec = Executors.newSingleThreadExecutor()
    private var ws: WebSocket? = null
    private var rec: AudioRecord? = null
    private var track: AudioTrack? = null
    private var am: AudioManager = ctx.getSystemService(Context.AUDIO_SERVICE) as AudioManager
    @Volatile private var ready = false
    @Volatile private var stopped = false
    private val uText = StringBuilder()
    private val pText = StringBuilder()
    private val pendingText = java.util.concurrent.ConcurrentLinkedQueue<String>()

    private val toolsJson = """[{"functionDeclarations":[
      {"name":"open_app","description":"Phone me app kholo","parameters":{"type":"OBJECT","properties":{"app_name":{"type":"STRING"}},"required":["app_name"]}},
      {"name":"read_screen","description":"Abhi screen par jo likha hai wo padho"},
      {"name":"click_text","description":"Screen par is text wale button/item par tap karo","parameters":{"type":"OBJECT","properties":{"text":{"type":"STRING"}},"required":["text"]}},
      {"name":"type_text","description":"Focused text box me text likho","parameters":{"type":"OBJECT","properties":{"text":{"type":"STRING"}},"required":["text"]}},
      {"name":"global_action","description":"home, back, recents, notifications ya lock","parameters":{"type":"OBJECT","properties":{"action":{"type":"STRING"}},"required":["action"]}},
      {"name":"scroll","description":"Screen scroll karo","parameters":{"type":"OBJECT","properties":{"direction":{"type":"STRING","description":"up ya down"}},"required":["direction"]}},
      {"name":"call_contact","description":"Contact ko call lagao","parameters":{"type":"OBJECT","properties":{"name":{"type":"STRING"}},"required":["name"]}},
      {"name":"remember","description":"User ki koi zaroori baat hamesha yaad rakho","parameters":{"type":"OBJECT","properties":{"fact":{"type":"STRING"}},"required":["fact"]}}
    ]}]"""

    fun start() {
        stopped = false
        am.mode = AudioManager.MODE_IN_COMMUNICATION
        routeAudioToPreferredDevice()
        initTrack(); startMic(); connect()
    }

    /** Prefer a paired Bluetooth headset/speaker for AJ voice output when Android exposes it. */
    private fun routeAudioToPreferredDevice() {
        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                val preferred = am.availableCommunicationDevices.firstOrNull {
                    it.type == AudioDeviceInfo.TYPE_BLE_HEADSET ||
                    it.type == AudioDeviceInfo.TYPE_BLUETOOTH_SCO
                }
                if (preferred != null) {
                    val routed = am.setCommunicationDevice(preferred)
                    PriyaState.status.value = if (routed) "Bluetooth connected: ${preferred.productName}" else "Bluetooth route unavailable; phone mic active"
                } else {
                    am.clearCommunicationDevice()
                    PriyaState.status.value = "Phone speaker / connected audio"
                }
            } else {
                @Suppress("DEPRECATION")
                val hasBt = am.getDevices(AudioManager.GET_DEVICES_OUTPUTS).any {
                    it.type == AudioDeviceInfo.TYPE_BLUETOOTH_SCO || it.type == AudioDeviceInfo.TYPE_BLUETOOTH_A2DP
                }
                if (hasBt) {
                    @Suppress("DEPRECATION")
                    am.startBluetoothSco()
                    @Suppress("DEPRECATION")
                    am.isBluetoothScoOn = true
                    PriyaState.status.value = "Connecting Bluetooth microphone…"
                } else {
                    @Suppress("DEPRECATION")
                    am.isSpeakerphoneOn = true
                }
            }
        } catch (_: SecurityException) {
            PriyaState.status.value = "Bluetooth permission allow karo; phone audio active"
        } catch (_: Exception) {
            PriyaState.status.value = "Phone audio active"
        }
    }

    fun stop() {
        stopped = true; ready = false
        ws?.close(1000, "bye"); ws = null
        rec?.run { try { stop() } catch (_: Exception) {}; release() }; rec = null
        track?.run { try { stop() } catch (_: Exception) {}; release() }; track = null
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) am.clearCommunicationDevice() else {
            @Suppress("DEPRECATION")
            run { am.stopBluetoothSco(); am.isBluetoothScoOn = false; am.isSpeakerphoneOn = false }
        }
        am.mode = AudioManager.MODE_NORMAL
    }

    private fun connect() {
        val key = Store.apiKey(ctx)
        if (key.isBlank()) { PriyaState.status.value = "API key daalo (Menu)"; return }
        PriyaState.status.value = "Connecting…"
        val url = "wss://generativelanguage.googleapis.com/ws/google.ai.generativelanguage.v1beta.GenerativeService.BidiGenerateContent?key=$key"
        ws = client.newWebSocket(Request.Builder().url(url).build(), object : WebSocketListener() {
            override fun onOpen(w: WebSocket, r: Response) {
                PriyaState.status.value = "Connected; configuring AJ…"
                if (!w.send(setup().toString())) fail("Setup send nahi hua")
            }
            override fun onMessage(w: WebSocket, text: String) = handle(text)
            override fun onMessage(w: WebSocket, bytes: ByteString) = handle(bytes.utf8())
            override fun onFailure(w: WebSocket, t: Throwable, r: Response?) {
                val detail = r?.let { " HTTP ${it.code}: ${it.message}" } ?: ""
                fail("Connection error: ${(t.message ?: "unknown").take(90)}$detail")
            }
            override fun onClosed(w: WebSocket, code: Int, reason: String) {
                if (!stopped) fail("Server closed ($code): ${reason.take(70)}")
            }
        })
    }

    private fun fail(msg: String) {
        ready = false
        if (stopped) return
        PriyaState.status.value = msg
        main.postDelayed({ if (!stopped) connect() }, 3000)
    }

    private fun setup(): JSONObject {
        val sys = "Tum AJ ho, ek friendly, helpful AI assistant. Hinglish me, chhote natural sentences me, " +
            "female voice me baat karo (feminine grammar: 'main kar rahi hoon'). Phone control ke liye tools use karo: " +
            "app kholna, screen padhna, tap karna, type karna, scroll, call. Koi bhi zaroori baat user bataye to remember tool se save karo. " +
            "Purani yaaddasht (memory):\n" + Store.recent(ctx)
        val s = JSONObject("""{"generationConfig":{"responseModalities":["AUDIO"],"speechConfig":{"voiceConfig":{"prebuiltVoiceConfig":{"voiceName":"Aoede"}}}},"inputAudioTranscription":{},"outputAudioTranscription":{}}""")
        s.put("model", "models/" + Store.model(ctx))
        s.put("systemInstruction", JSONObject().put("parts", JSONArray().put(JSONObject().put("text", sys))))
        s.put("tools", JSONArray(toolsJson))
        return JSONObject().put("setup", s)
    }

    private fun handle(msg: String) {
        val j = JSONObject(msg)
        if (j.has("setupComplete")) {
            ready = true
            PriyaState.status.value = "AJ ready — bolo ya type karo"
            while (true) {
                val queued = pendingText.poll() ?: break
                sendTextNow(queued)
            }
        }
        j.optJSONObject("error")?.let { err ->
            val message = err.optString("message", "Gemini ne request reject kar di")
            PriyaState.addLog("AI error: $message")
            fail("Gemini error: ${message.take(110)}")
            return
        }
        j.optJSONObject("serverContent")?.let { sc ->
            if (sc.optBoolean("interrupted")) { track?.run { pause(); flush(); play() } }
            sc.optJSONObject("inputTranscription")?.optString("text")?.let { uText.append(it) }
            sc.optJSONObject("outputTranscription")?.optString("text")?.let { pText.append(it) }
            sc.optJSONObject("modelTurn")?.optJSONArray("parts")?.let { ps ->
                for (i in 0 until ps.length()) ps.getJSONObject(i).optJSONObject("inlineData")?.let {
                    val pcm = Base64.decode(it.getString("data"), Base64.DEFAULT)
                    PriyaState.status.value = "AJ bol raha hai…"
                    playExec.execute {
                        val output = track
                        if (output != null && output.state == AudioTrack.STATE_INITIALIZED) {
                            var offset = 0
                            while (offset < pcm.size && !stopped) {
                                val written = output.write(pcm, offset, pcm.size - offset)
                                if (written <= 0) break
                                offset += written
                            }
                        } else {
                            PriyaState.status.value = "Audio output initialize nahi hua"
                        }
                    }
                }
            }
            if (sc.optBoolean("turnComplete")) {
                val u = uText.toString().trim(); val p = pText.toString().trim()
                if (u.isNotEmpty()) { Store.remember(ctx, "User: $u"); PriyaState.addLog("Tum: $u") }
                if (p.isNotEmpty()) { Store.remember(ctx, "AJ: $p"); PriyaState.addLog("AJ: $p") }
                uText.setLength(0); pText.setLength(0)
                PriyaState.status.value = "Listening…"
            }
        }
        j.optJSONObject("toolCall")?.optJSONArray("functionCalls")?.let { fc ->
            val out = JSONArray()
            for (i in 0 until fc.length()) {
                val c = fc.getJSONObject(i)
                val r = runTool(c.getString("name"), c.optJSONObject("args") ?: JSONObject())
                out.put(JSONObject().put("id", c.getString("id")).put("name", c.getString("name"))
                    .put("response", JSONObject().put("result", r)))
            }
            ws?.send(JSONObject().put("toolResponse", JSONObject().put("functionResponses", out)).toString())
        }
    }

    private fun runTool(name: String, a: JSONObject): String = try {
        val noAcc = "AJ advanced screen control service connected nahi hai. Android Settings > Accessibility > AJ advanced screen control enable karo."
        when (name) {
            "open_app" -> openApp(a.optString("app_name"))
            "read_screen" -> {
                if (!AJAccessibilityService.isConnected()) noAcc
                else {
                    AJAccessibilityService.refreshScreen()
                    val accessibilityText = AJAccessibilityService.currentScreenText()
                    val ocrText = ScreenFrameStore.frame.value?.recognizedText.orEmpty()
                    buildString {
                        append(accessibilityText)
                        if (ocrText.isNotBlank()) append("\n\nScreen OCR text:\n").append(ocrText.take(5000))
                    }.take(9000)
                }
            }
            "click_text" -> if (!AJAccessibilityService.isConnected()) noAcc else
                if (AJAccessibilityService.executeAction(PlannedAction(type = "tap_text", text = a.optString("text")))) "Tapped '${a.optString("text")}'." else "Text '${a.optString("text")}' nahi mila ya tappable nahi hai."
            "type_text" -> if (!AJAccessibilityService.isConnected()) noAcc else
                if (AJAccessibilityService.executeAction(PlannedAction(type = "type_text", text = a.optString("text")))) "Text field mein text enter kar diya. Send/submit nahi kiya." else "Koi focused editable text field nahi mila."
            "global_action" -> if (!AJAccessibilityService.isConnected()) noAcc else {
                val action = when (a.optString("action").lowercase()) {
                    "home" -> "home"; "back" -> "back"; "recents" -> "recents"; "notifications" -> "notifications"; "lock" -> "lock"; else -> ""
                }
                if (action.isBlank()) "Unknown global action." else if (AJAccessibilityService.executeAction(PlannedAction(type = action))) "Done: $action" else "Action failed."
            }
            "scroll" -> if (!AJAccessibilityService.isConnected()) noAcc else
                if (AJAccessibilityService.executeAction(PlannedAction(type = "scroll", direction = a.optString("direction")))) "Screen scrolled." else "Scrollable area nahi mila."
            "call_contact" -> callContact(a.optString("name"))
            "remember" -> { Store.remember(ctx, "FACT: " + a.optString("fact")); "saved" }
            else -> "unknown tool"
        }
    } catch (e: Exception) { "error: ${e.message}" }

    private fun openApp(n: String): String {
        val pm = ctx.packageManager
        val li = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        val m = pm.queryIntentActivities(li, 0).firstOrNull { it.loadLabel(pm).toString().contains(n, true) } ?: return "app nahi mila"
        ctx.startActivity(Intent(li).setClassName(m.activityInfo.packageName, m.activityInfo.name).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        return "opened ${m.loadLabel(pm)}"
    }

    private fun callContact(n: String): String {
        val c = ctx.contentResolver.query(ContactsContract.CommonDataKinds.Phone.CONTENT_URI,
            arrayOf(ContactsContract.CommonDataKinds.Phone.NUMBER),
            ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME + " LIKE ?", arrayOf("%$n%"), null)
        val num = c?.use { if (it.moveToFirst()) it.getString(0) else null } ?: return "contact nahi mila"
        ctx.startActivity(Intent(Intent.ACTION_CALL, android.net.Uri.parse("tel:$num")).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        return "calling $n"
    }

    private fun initTrack() {
        track = AudioTrack.Builder()
            .setAudioAttributes(AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_VOICE_COMMUNICATION).setContentType(AudioAttributes.CONTENT_TYPE_SPEECH).build())
            .setAudioFormat(AudioFormat.Builder().setSampleRate(24000).setEncoding(AudioFormat.ENCODING_PCM_16BIT).setChannelMask(AudioFormat.CHANNEL_OUT_MONO).build())
            .setBufferSizeInBytes(AudioTrack.getMinBufferSize(24000, AudioFormat.CHANNEL_OUT_MONO, AudioFormat.ENCODING_PCM_16BIT) * 4)
            .setTransferMode(AudioTrack.MODE_STREAM).build().also { it.play() }
    }

    private fun startMic() {
        try {
            val min = AudioRecord.getMinBufferSize(16000, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT)
            if (min <= 0) { PriyaState.status.value = "Microphone format unsupported ($min)"; return }
            val r = AudioRecord.Builder()
                .setAudioSource(MediaRecorder.AudioSource.VOICE_COMMUNICATION)
                .setAudioFormat(AudioFormat.Builder().setSampleRate(16000)
                    .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                    .setChannelMask(AudioFormat.CHANNEL_IN_MONO).build())
                .setBufferSizeInBytes(maxOf(min * 2, 12800)).build()
            if (r.state != AudioRecord.STATE_INITIALIZED) {
                r.release(); PriyaState.status.value = "Microphone initialize nahi hua — permission check karo"; return
            }
            // Android may expose the Bluetooth headset as a communication input.
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                val btInput = am.getDevices(AudioManager.GET_DEVICES_INPUTS).firstOrNull {
                    it.type == AudioDeviceInfo.TYPE_BLUETOOTH_SCO ||
                    (Build.VERSION.SDK_INT >= 31 && it.type == AudioDeviceInfo.TYPE_BLE_HEADSET)
                }
                if (btInput != null) r.setPreferredDevice(btInput)
            }
            if (AcousticEchoCanceler.isAvailable()) AcousticEchoCanceler.create(r.audioSessionId)?.enabled = true
            if (NoiseSuppressor.isAvailable()) NoiseSuppressor.create(r.audioSessionId)?.enabled = true
            rec = r
            r.startRecording()
            if (r.recordingState != AudioRecord.RECORDSTATE_RECORDING) {
                PriyaState.status.value = "Microphone recording start nahi hua"; return
            }
            PriyaState.status.value = "Mic active — AJ ko boliye"
            Thread {
                val buf = ByteArray(3200)
                while (!stopped) {
                    val n = r.read(buf, 0, buf.size)
                    if (n > 0 && ready) {
                        val d = Base64.encodeToString(buf, 0, n, Base64.NO_WRAP)
                        val sent = ws?.send("""{"realtimeInput":{"audio":{"data":"$d","mimeType":"audio/pcm;rate=16000"}}}""") ?: false
                        if (!sent) PriyaState.status.value = "Audio connection lost — reconnecting…"
                    } else if (n < 0) {
                        PriyaState.status.value = "Microphone read error ($n)"
                        break
                    }
                }
            }.start()
        } catch (e: SecurityException) {
            PriyaState.status.value = "Mic/Bluetooth permission allow karo"
        } catch (e: Exception) {
            PriyaState.status.value = "Mic error: ${(e.message ?: "unknown").take(70)}"
        }
    }

    fun sendText(t: String) {
        if (t.isBlank()) return
        PriyaState.addLog("Tum: $t")
        Store.remember(ctx, "User(text): $t")
        if (!ready || ws == null) {
            pendingText.offer(t)
            PriyaState.status.value = "AJ connect ho raha hai — message queue me hai"
            if (ws == null) connect()
            return
        }
        sendTextNow(t)
    }

    private fun sendTextNow(t: String) {
        val socket = ws
        if (socket == null || !ready || !socket.send(
                JSONObject().put("realtimeInput", JSONObject().put("text", t)).toString()
            )) {
            pendingText.offer(t)
            PriyaState.status.value = "Message send nahi hua; reconnect ho raha hai"
        } else {
            PriyaState.status.value = "AJ soch raha hai…"
        }
    }

    fun sendImage(jpeg: ByteArray) {
        val d = Base64.encodeToString(jpeg, Base64.NO_WRAP)
        ws?.send("""{"realtimeInput":{"video":{"data":"$d","mimeType":"image/jpeg"}}}""")
    }
}
