#!/data/data/com.termux/files/usr/bin/bash
# Ek baar chalao: bash setup_termux.sh
set -e
cd "$(dirname "$0")"
pkg update -y
pkg install -y openjdk-17 gradle aapt2 unzip zip wget
SDK="$HOME/android-sdk"
mkdir -p "$SDK"
echo "sdk.dir=$SDK" > local.properties
grep -q aapt2FromMavenOverride gradle.properties || echo "android.aapt2FromMavenOverride=$PREFIX/bin/aapt2" >> gradle.properties
echo
if [ ! -f "$SDK/platforms/android-34/android.jar" ]; then
  echo "!! Android SDK nahi mila: $SDK/platforms/android-34/android.jar"
  echo "   ARM (aarch64) Android SDK (platform-34 + build-tools 34) is folder me rakho, phir build.sh chalao."
else
  echo "SDK mil gaya. Ab: bash build.sh"
fi
