#!/data/data/com.termux/files/usr/bin/bash
# APK banao: bash build.sh
cd "$(dirname "$0")"
export JAVA_HOME="$PREFIX/lib/jvm/java-17-openjdk"
V=$(gradle --version | awk '/^Gradle/{print $2}')
case "$V" in 9.*) echo "Warning: Gradle $V bahut naya hai, AGP 8.5.2 ke liye Gradle 8.7-8.x chahiye";; esac
gradle --no-daemon -Dorg.gradle.jvmargs=-Xmx1g assembleDebug || exit 1
APK=app/build/outputs/apk/debug/app-debug.apk
echo "APK ready: $APK"
[ -d /sdcard/Download ] && cp "$APK" /sdcard/Download/PriyaAI.apk && echo "Copy hua: /sdcard/Download/PriyaAI.apk"
