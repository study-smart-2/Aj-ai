package com.priya.ai

import android.accessibilityservice.AccessibilityService
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo
import android.os.Bundle

class PriyaAccessibility : AccessibilityService() {
    companion object { @Volatile var instance: PriyaAccessibility? = null }

    override fun onServiceConnected() { instance = this }
    override fun onUnbind(intent: android.content.Intent?): Boolean { instance = null; return super.onUnbind(intent) }
    override fun onAccessibilityEvent(e: AccessibilityEvent?) {}
    override fun onInterrupt() {}

    fun readScreen(): String {
        val sb = StringBuilder()
        fun walk(n: AccessibilityNodeInfo?, d: Int) {
            if (n == null || sb.length > 4000) return
            val t = n.text?.toString() ?: n.contentDescription?.toString()
            if (!t.isNullOrBlank()) sb.append(t.take(150)).append(if (n.isClickable) " [button]" else "").append('\n')
            for (i in 0 until n.childCount) walk(n.getChild(i), d + 1)
        }
        walk(rootInActiveWindow, 0)
        return sb.toString().ifBlank { "screen par kuch padhne layak nahi mila" }
    }

    fun clickText(t: String): String {
        val nodes = rootInActiveWindow?.findAccessibilityNodeInfosByText(t) ?: return "screen available nahi"
        for (n in nodes) {
            var c: AccessibilityNodeInfo? = n
            while (c != null && !c.isClickable) c = c.parent
            if (c != null && c.performAction(AccessibilityNodeInfo.ACTION_CLICK)) return "clicked $t"
        }
        return "'$t' screen par nahi mila"
    }

    fun typeText(t: String): String {
        val f = rootInActiveWindow?.findFocus(AccessibilityNodeInfo.FOCUS_INPUT) ?: return "koi text box focus mein nahi"
        val b = Bundle().apply { putCharSequence(AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE, t) }
        return if (f.performAction(AccessibilityNodeInfo.ACTION_SET_TEXT, b)) "typed" else "type nahi hua"
    }

    fun global(a: String): String {
        val act = when (a) {
            "home" -> GLOBAL_ACTION_HOME; "back" -> GLOBAL_ACTION_BACK
            "recents" -> GLOBAL_ACTION_RECENTS; "notifications" -> GLOBAL_ACTION_NOTIFICATIONS
            "lock" -> GLOBAL_ACTION_LOCK_SCREEN; else -> return "unknown action"
        }
        return if (performGlobalAction(act)) "done" else "failed"
    }

    fun scroll(dir: String): String {
        fun find(n: AccessibilityNodeInfo?): AccessibilityNodeInfo? {
            if (n == null) return null
            if (n.isScrollable) return n
            for (i in 0 until n.childCount) find(n.getChild(i))?.let { return it }
            return null
        }
        val s = find(rootInActiveWindow) ?: return "scroll hone wali cheez nahi mili"
        val a = if (dir == "up") AccessibilityNodeInfo.ACTION_SCROLL_BACKWARD else AccessibilityNodeInfo.ACTION_SCROLL_FORWARD
        return if (s.performAction(a)) "scrolled" else "scroll fail"
    }
}
