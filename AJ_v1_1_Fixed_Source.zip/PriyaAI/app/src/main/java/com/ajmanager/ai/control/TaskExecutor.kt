package com.ajmanager.ai.control

import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.delay

data class StepResult(
    val index: Int,
    val action: String,
    val executed: Boolean,
    val verified: Boolean?,
    val detail: String
)

data class TaskResult(
    val completed: Boolean,
    val cancelled: Boolean,
    val steps: List<StepResult>,
    val summary: String
)

object TaskExecutor {
    suspend fun run(plan: ActionPlan, onStep: (StepResult) -> Unit = {}): TaskResult {
        val results = mutableListOf<StepResult>()
        return try {
            plan.actions.forEachIndexed { index, action ->
                val executed = AJAccessibilityService.executeAction(action)
                delay(action.waitMs)
                AJAccessibilityService.refreshScreen()
                val screen = AJAccessibilityService.visibleScreen.value
                val verified = when {
                    !executed -> false
                    !action.expectedText.isNullOrBlank() ->
                        screen?.elements?.any {
                            it.text.contains(action.expectedText, true) ||
                                it.description.contains(action.expectedText, true)
                        } == true
                    action.type == "verify_text" ->
                        screen?.elements?.any {
                            it.text.contains(action.text.orEmpty(), true) ||
                                it.description.contains(action.text.orEmpty(), true)
                        } == true
                    else -> null
                }
                val detail = when {
                    !executed -> "Action could not be performed. Stopped to avoid guessing."
                    verified == true -> "Expected visible result found."
                    verified == false -> "Expected result not found. Stopped; inspect the current screen."
                    else -> "Action dispatched. No explicit postcondition was supplied; inspect the screen."
                }
                val result = StepResult(index + 1, action.type, executed, verified, detail)
                results += result
                onStep(result)
                if (!executed || verified == false) {
                    return TaskResult(false, false, results, "Stopped at step ${index + 1}.")
                }
            }
            TaskResult(true, false, results, "All ${results.size} step(s) dispatched.")
        } catch (cancelled: CancellationException) {
            TaskResult(false, true, results, "Task cancelled after ${results.size} step(s).")
        }
    }
}
