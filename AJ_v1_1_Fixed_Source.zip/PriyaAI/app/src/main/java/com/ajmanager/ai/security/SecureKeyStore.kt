package com.ajmanager.ai.security

import android.content.Context
import android.security.keystore.KeyGenParameterSpec
import android.security.keystore.KeyProperties
import android.util.Base64
import java.security.KeyStore
import javax.crypto.Cipher
import javax.crypto.KeyGenerator
import javax.crypto.SecretKey
import javax.crypto.spec.GCMParameterSpec

/** Encrypts provider API keys with an AES key held by Android Keystore. */
class SecureKeyStore(context: Context) {
    private val prefs = context.getSharedPreferences("aj_secure_config", Context.MODE_PRIVATE)
    private val alias = "aj_manager_ai_api_key_v1"

    fun save(provider: String, apiKey: String) {
        require(apiKey.isNotBlank()) { "API key is empty." }
        val cipher = Cipher.getInstance(TRANSFORMATION)
        cipher.init(Cipher.ENCRYPT_MODE, getOrCreateKey())
        val encrypted = cipher.doFinal(apiKey.toByteArray(Charsets.UTF_8))
        val iv = Base64.encodeToString(cipher.iv, Base64.NO_WRAP)
        val payload = Base64.encodeToString(encrypted, Base64.NO_WRAP)
        check(prefs.edit().putString("${provider}_iv", iv).putString(provider, payload).commit()) {
            "Could not save encrypted API key."
        }
    }

    fun load(provider: String): String? {
        val iv = prefs.getString("${provider}_iv", null) ?: return null
        val payload = prefs.getString(provider, null) ?: return null
        return try {
            val cipher = Cipher.getInstance(TRANSFORMATION)
            cipher.init(Cipher.DECRYPT_MODE, getOrCreateKey(), GCMParameterSpec(128, Base64.decode(iv, Base64.NO_WRAP)))
            String(cipher.doFinal(Base64.decode(payload, Base64.NO_WRAP)), Charsets.UTF_8)
        } catch (_: Exception) {
            // Key invalidation or corrupted ciphertext: remove unusable entry, never fall back to plaintext.
            clear(provider)
            null
        }
    }

    fun clear(provider: String) {
        prefs.edit().remove(provider).remove("${provider}_iv").apply()
    }

    private fun getOrCreateKey(): SecretKey {
        val store = KeyStore.getInstance("AndroidKeyStore").apply { load(null) }
        (store.getKey(alias, null) as? SecretKey)?.let { return it }
        val generator = KeyGenerator.getInstance(KeyProperties.KEY_ALGORITHM_AES, "AndroidKeyStore")
        generator.init(
            KeyGenParameterSpec.Builder(
                alias,
                KeyProperties.PURPOSE_ENCRYPT or KeyProperties.PURPOSE_DECRYPT
            ).setBlockModes(KeyProperties.BLOCK_MODE_GCM)
                .setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_NONE)
                .setRandomizedEncryptionRequired(true)
                .build()
        )
        return generator.generateKey()
    }

    companion object { private const val TRANSFORMATION = "AES/GCM/NoPadding" }
}
