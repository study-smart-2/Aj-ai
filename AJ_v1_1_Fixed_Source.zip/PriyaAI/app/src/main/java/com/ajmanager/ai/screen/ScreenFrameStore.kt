package com.ajmanager.ai.screen

import android.graphics.Bitmap
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

data class ScreenFrame(
    val bitmap: Bitmap,
    val recognizedText: String,
    val capturedAtMillis: Long
)

object ScreenFrameStore {
    private val _frame = MutableStateFlow<ScreenFrame?>(null)
    val frame: StateFlow<ScreenFrame?> = _frame.asStateFlow()

    fun publish(bitmap: Bitmap, text: String) {
        _frame.value = ScreenFrame(bitmap, text, System.currentTimeMillis())
    }

    fun clear() {
        _frame.value = null
    }
}
