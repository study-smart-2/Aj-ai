package com.ajmanager.ai.ai

import android.graphics.Bitmap
import android.util.Base64
import java.io.ByteArrayOutputStream
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.util.concurrent.TimeUnit

enum class ProviderKind(val label: String) { GEMINI("Google Gemini"), OPENAI("OpenAI"), OPENROUTER("OpenRouter") }
data class ProviderConfig(val kind: ProviderKind, val apiKey: String)

class ProviderRouter(private val config: ProviderConfig) {
    private val client = OkHttpClient.Builder().callTimeout(90, TimeUnit.SECONDS).build()


    suspend fun analyzeScreen(bitmap: Bitmap, ocrText: String): String = withContext(Dispatchers.IO) {
        val output = ByteArrayOutputStream()
        bitmap.compress(Bitmap.CompressFormat.JPEG, 65, output)
        val encoded = Base64.encodeToString(output.toByteArray(), Base64.NO_WRAP)
        val prompt = "Describe the visible app screen for an accessibility assistant. Identify only clearly visible labels, controls, chat/channel title and likely current screen. Do not infer hidden data. OCR text: ${ocrText.take(6000)}"
        val (url, body) = when (config.kind) {
            ProviderKind.GEMINI -> {
                val parts = JSONArray()
                    .put(JSONObject().put("text", prompt))
                    .put(JSONObject().put("inline_data", JSONObject().put("mime_type", "image/jpeg").put("data", encoded)))
                "https://generativelanguage.googleapis.com/v1beta/models/gemini-2.0-flash:generateContent?key=${config.apiKey}" to
                    JSONObject().put("contents", JSONArray().put(JSONObject().put("parts", parts)))
            }
            ProviderKind.OPENAI, ProviderKind.OPENROUTER -> {
                val endpoint = if (config.kind == ProviderKind.OPENAI) "https://api.openai.com/v1/chat/completions" else "https://openrouter.ai/api/v1/chat/completions"
                val model = if (config.kind == ProviderKind.OPENAI) "gpt-4o-mini" else "openai/gpt-4o-mini"
                val content = JSONArray()
                    .put(JSONObject().put("type", "text").put("text", prompt))
                    .put(JSONObject().put("type", "image_url").put("image_url", JSONObject().put("url", "data:image/jpeg;base64,$encoded")))
                endpoint to JSONObject().put("model", model).put("messages",
                    JSONArray().put(JSONObject().put("role", "user").put("content", content)))
            }
        }
        val request = Request.Builder().url(url).post(body.toString().toRequestBody("application/json".toMediaType()))
        if (config.kind != ProviderKind.GEMINI) request.header("Authorization", "Bearer ${config.apiKey}")
        client.newCall(request.build()).execute().use { response ->
            if (!response.isSuccessful) error("Vision provider HTTP ${response.code}: ${response.body?.string()?.take(200)}")
            val raw = response.body?.string() ?: error("Empty vision response")
            if (config.kind == ProviderKind.GEMINI) {
                JSONObject(raw).getJSONArray("candidates").getJSONObject(0)
                    .getJSONObject("content").getJSONArray("parts").getJSONObject(0).getString("text")
            } else {
                JSONObject(raw).getJSONArray("choices").getJSONObject(0)
                    .getJSONObject("message").getString("content")
            }
        }
    }

    suspend fun plan(task: String, screenContext: String = ""): String = withContext(Dispatchers.IO) {
        val systemPrompt = """
            You are AJ Manager AI. Return ONLY JSON:
            {"summary":"short plan","actions":[{"type":"open_app","package":"org.telegram.messenger"}]}
            Allowed action types: open_app, tap_text, tap, type_text, scroll, back, long_press_text, verify_text, read_screen.
            tap uses normalized x and y from 0 to 1. tap_text and long_press_text use visible text.
            verify_text checks whether visible text exists. read_screen refreshes the visible UI snapshot.
            For Telegram use package org.telegram.messenger. Use only visible screen context; never invent chat names, buttons, message contents, or media.
            For a Telegram task, inspect the current screen first, then perform a small number of grounded UI actions, then verify visible result with verify_text or read_screen.
            For forwarding, sending, posting, uploading, sharing, saving media, deleting, purchases, payments, leaving groups, or other irreversible/private actions, set requires_confirmation=true BUT still return the proposed action steps so the app can show them to the user for approval before execution.
            Never request passwords, OTPs, payment credentials, or login codes. Never claim success from a tap alone.
            Limit each plan to at most 8 actions. Include expected_text only when a clear visible confirmation label or screen text is predictable. Never invent a confirmation label.
            Use wait_ms between 400 and 1500. Do not repeat a tap to compensate for uncertainty.
            For message composition, draft text in the editor but do not press Send unless the user has approved the complete plan.
            For forwarding, require the user to identify/select the exact source message and destination; do not guess.
            For media, use only the Android/Telegram visible picker and user-selected items. Do not access hidden Telegram databases or private app files.
            If required UI elements are not visible, ask the user to navigate to the correct Telegram screen rather than guessing coordinates.
            Work only on the user's explicit task.
        """.trimIndent()
        val (url, body) = when (config.kind) {
            ProviderKind.GEMINI -> {
                val userPrompt = task + if (screenContext.isBlank()) "" else "\n\nCURRENT SCREEN CONTEXT:\n" + screenContext
                val systemParts = JSONArray().put(JSONObject().put("text", systemPrompt))
                val userParts = JSONArray().put(JSONObject().put("text", userPrompt))
                val b = JSONObject()
                    .put("system_instruction", JSONObject().put("parts", systemParts))
                    .put("contents", JSONArray().put(JSONObject().put("parts", userParts)))
                "https://generativelanguage.googleapis.com/v1beta/models/gemini-2.0-flash:generateContent?key=${config.apiKey}" to b
            }
            ProviderKind.OPENAI, ProviderKind.OPENROUTER -> {
                val u = if (config.kind == ProviderKind.OPENAI) "https://api.openai.com/v1/chat/completions" else "https://openrouter.ai/api/v1/chat/completions"
                val model = if (config.kind == ProviderKind.OPENAI) "gpt-4o-mini" else "openai/gpt-4o-mini"
                val msgs = JSONArray().put(JSONObject().put("role", "system").put("content", systemPrompt))
                    .put(JSONObject().put("role", "user").put("content", task + if (screenContext.isBlank()) "" else "\n\nCURRENT SCREEN CONTEXT:\n" + screenContext))
                u to JSONObject().put("model", model).put("messages", msgs)
            }
        }
        val rb = Request.Builder().url(url).post(body.toString().toRequestBody("application/json".toMediaType()))
        if (config.kind != ProviderKind.GEMINI) rb.header("Authorization", "Bearer ${config.apiKey}")
        client.newCall(rb.build()).execute().use { response ->
            if (!response.isSuccessful) error("Provider HTTP ${response.code}: ${response.body?.string()?.take(250)}")
            val raw = response.body?.string() ?: error("Empty AI response")
            if (config.kind == ProviderKind.GEMINI)
                JSONObject(raw).getJSONArray("candidates").getJSONObject(0).getJSONObject("content").getJSONArray("parts").getJSONObject(0).getString("text")
            else JSONObject(raw).getJSONArray("choices").getJSONObject(0).getJSONObject("message").getString("content")
        }
    }
}
