package com.ajmanager.ai.control

import org.json.JSONObject

data class PlannedAction(
    val type: String,
    val text: String? = null,
    val packageName: String? = null,
    val x: Float? = null,
    val y: Float? = null,
    val direction: String? = null,
    val exact: Boolean = false,
    val expectedText: String? = null,
    val waitMs: Long = 650L
)

data class ActionPlan(
    val summary: String,
    val actions: List<PlannedAction>,
    val requiresConfirmation: Boolean
)

object ActionPlanParser {
    fun parse(raw: String): ActionPlan {
        val clean = raw.substringAfter("```json", raw).substringBefore("```").trim()
        val json = JSONObject(clean)
        val array = json.optJSONArray("actions")
        val actions = buildList {
            if (array != null) for (i in 0 until array.length()) {
                val a = array.getJSONObject(i)
                add(
                    PlannedAction(
                        type = a.optString("type"),
                        text = a.optString("text").takeIf(String::isNotBlank),
                        packageName = a.optString("package").takeIf(String::isNotBlank),
                        x = if (a.has("x")) a.optDouble("x").toFloat() else null,
                        y = if (a.has("y")) a.optDouble("y").toFloat() else null,
                        direction = a.optString("direction").takeIf(String::isNotBlank),
                        exact = a.optBoolean("exact", false),
                        expectedText = a.optString("expected_text").takeIf(String::isNotBlank),
                        waitMs = a.optLong("wait_ms", 650L).coerceIn(250L, 2500L)
                    )
                )
            }
        }
        return ActionPlan(
            summary = json.optString("summary"),
            actions = actions,
            requiresConfirmation = json.optBoolean("requires_confirmation")
        )
    }
}

data class PolicyDecision(val allowed: Boolean, val reason: String = "", val needsConfirmation: Boolean = false)

object AutonomyPolicy {
    private val allowlist = setOf(
        "open_app", "tap_text", "tap", "type_text", "scroll", "back",
        "long_press_text", "verify_text", "read_screen"
    )
    private val sensitiveActionLabels = listOf(
        "send", "forward", "post", "publish", "delete", "remove", "purchase",
        "buy", "pay", "payment", "transfer", "share", "upload", "submit",
        "invite", "leave group", "block", "report", "save to", "confirm"
    )

    fun evaluate(plan: ActionPlan, autonomous: Boolean, confirmed: Boolean = false): PolicyDecision {
        if (plan.actions.size > 12) return PolicyDecision(false, "A task is limited to 12 steps.")
        if (plan.actions.any { it.type !in allowlist }) return PolicyDecision(false, "Unsupported action in plan.")
        if (plan.actions.any { it.type == "tap" && (it.x == null || it.y == null || it.x !in 0f..1f || it.y !in 0f..1f) }) {
            return PolicyDecision(false, "Invalid tap coordinates.")
        }
        if (plan.actions.any { it.type == "type_text" && (it.text ?: "").length > 2000 }) {
            return PolicyDecision(false, "Text exceeds the 2,000-character limit.")
        }
        val labels = plan.actions.joinToString(" ") { "${it.type} ${it.text.orEmpty()}" }.lowercase()
        // Text entry may contain private content, and coordinate taps may target unlabeled
        // Send/Publish controls. Stage both for explicit user review.
        val sensitive = plan.requiresConfirmation ||
            sensitiveActionLabels.any(labels::contains) ||
            plan.actions.any { it.type == "type_text" || it.type == "tap" }
        if (sensitive && !confirmed) return PolicyDecision(
            false, "This task may send, forward, publish, upload, share, save, delete or change account data.",
            true
        )
        if (!autonomous && !confirmed && plan.actions.isNotEmpty()) {
            return PolicyDecision(false, "Supervised mode requires approval.", true)
        }
        return PolicyDecision(true)
    }
}
