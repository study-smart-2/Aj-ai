package com.ajmanager.ai.control

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.content.Intent
import android.graphics.Path
import android.os.Bundle
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.asStateFlow

data class VisibleElement(
    val text: String,
    val description: String,
    val className: String,
    val clickable: Boolean,
    val editable: Boolean,
    val bounds: String
)

data class VisibleScreen(
    val packageName: String,
    val elements: List<VisibleElement>,
    val capturedAt: Long
) {
    fun asPromptContext(): String = buildString {
        appendLine("Foreground package: $packageName")
        elements.take(100).forEachIndexed { index, e ->
            appendLine("${index + 1}. text='${e.text.take(180)}' description='${e.description.take(120)}' " +
                "class=${e.className} clickable=${e.clickable} editable=${e.editable} bounds=${e.bounds}")
        }
    }
}

class AJAccessibilityService : AccessibilityService() {
    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        if (event?.eventType == AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED ||
            event?.eventType == AccessibilityEvent.TYPE_WINDOW_CONTENT_CHANGED) {
            publishScreen()
        }
    }

    override fun onInterrupt() {}

    override fun onServiceConnected() {
        instance = this
        super.onServiceConnected()
        publishScreen()
    }

    override fun onDestroy() {
        if (instance === this) instance = null
        super.onDestroy()
    }

    private fun publishScreen() {
        val root = rootInActiveWindow ?: return
        val list = mutableListOf<VisibleElement>()
        collect(root, list, 0)
        _visibleScreen.value = VisibleScreen(
            packageName = root.packageName?.toString().orEmpty(),
            elements = list.distinctBy { "${it.text}|${it.description}|${it.bounds}" }.take(150),
            capturedAt = System.currentTimeMillis()
        )
    }

    private fun collect(node: AccessibilityNodeInfo, out: MutableList<VisibleElement>, depth: Int) {
        if (depth > 18 || out.size >= 150) return
        val rect = android.graphics.Rect()
        node.getBoundsInScreen(rect)
        val text = node.text?.toString().orEmpty()
        val desc = node.contentDescription?.toString().orEmpty()
        if (text.isNotBlank() || desc.isNotBlank() || node.isClickable || node.isEditable) {
            out += VisibleElement(
                text, desc, node.className?.toString().orEmpty(),
                node.isClickable, node.isEditable,
                "${rect.left},${rect.top},${rect.right},${rect.bottom}"
            )
        }
        for (i in 0 until node.childCount) {
            node.getChild(i)?.let { child ->
                collect(child, out, depth + 1)
                child.recycle()
            }
        }
    }

    private fun findNode(value: String, exact: Boolean = false): AccessibilityNodeInfo? {
        val root = rootInActiveWindow ?: return null
        val needle = value.trim()
        if (needle.isEmpty()) return null
        val candidates = root.findAccessibilityNodeInfosByText(needle)
        return candidates.firstOrNull { node ->
            val text = node.text?.toString().orEmpty()
            val desc = node.contentDescription?.toString().orEmpty()
            if (exact) text.equals(needle, true) || desc.equals(needle, true)
            else text.contains(needle, true) || desc.contains(needle, true)
        } ?: candidates.firstOrNull()
    }

    private fun clickText(value: String, exact: Boolean): Boolean {
        var current = findNode(value, exact) ?: return false
        repeat(12) {
            if (current.isClickable) return current.performAction(AccessibilityNodeInfo.ACTION_CLICK)
            val parent = current.parent ?: return false
            current = parent
        }
        return false
    }

    private fun longClickText(value: String, exact: Boolean): Boolean {
        var current = findNode(value, exact) ?: return false
        repeat(12) {
            if (current.isLongClickable) return current.performAction(AccessibilityNodeInfo.ACTION_LONG_CLICK)
            val parent = current.parent ?: return false
            current = parent
        }
        return false
    }

    private fun type(value: String): Boolean {
        val node = rootInActiveWindow?.findFocus(AccessibilityNodeInfo.FOCUS_INPUT) ?: return false
        return node.performAction(
            AccessibilityNodeInfo.ACTION_SET_TEXT,
            Bundle().apply { putCharSequence(AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE, value) }
        )
    }

    private fun tap(x: Float, y: Float): Boolean {
        val p = Path().apply {
            moveTo(x * resources.displayMetrics.widthPixels, y * resources.displayMetrics.heightPixels)
        }
        val gesture = GestureDescription.Builder()
            .addStroke(GestureDescription.StrokeDescription(p, 0, 80))
            .build()
        return dispatchGesture(gesture, null, null)
    }

    private fun execute(action: PlannedAction): Boolean {
        return when (action.type) {
            "open_app" -> {
                val pkg = action.packageName ?: return false
                val launch = packageManager.getLaunchIntentForPackage(pkg) ?: return false
                launch.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                startActivity(launch)
                true
            }
            "tap_text" -> clickText(action.text.orEmpty(), action.exact)
            "long_press_text" -> longClickText(action.text.orEmpty(), action.exact)
            "tap" -> {
                val x = action.x ?: return false
                val y = action.y ?: return false
                tap(x, y)
            }
            "type_text" -> type(action.text.orEmpty())
            "scroll" -> rootInActiveWindow?.performAction(
                if (action.direction == "up") AccessibilityNodeInfo.ACTION_SCROLL_BACKWARD
                else AccessibilityNodeInfo.ACTION_SCROLL_FORWARD
            ) ?: false
            "back" -> performGlobalAction(GLOBAL_ACTION_BACK)
            "verify_text" -> findNode(action.text.orEmpty(), action.exact) != null
            "read_screen" -> {
                publishScreen()
                true
            }
            else -> false
        }
    }

    companion object {
        @Volatile private var instance: AJAccessibilityService? = null
        private val _visibleScreen = MutableStateFlow<VisibleScreen?>(null)
        val visibleScreen = _visibleScreen.asStateFlow()

        fun executeAction(action: PlannedAction): Boolean {
            val service = instance ?: return false
            val result = service.execute(action)
            service.publishScreen()
            return result
        }

        fun executePlan(plan: ActionPlan): String {
            val service = instance ?: return "Accessibility service is not enabled."
            val results = plan.actions.map(service::execute)
            service.publishScreen()
            val passed = results.count { it }
            return "Dispatched $passed/${results.size} step(s). Inspect the screen to verify the intended result."
        }

        fun refreshScreen() {
            instance?.publishScreen()
        }

        fun currentScreenText(): String =
            _visibleScreen.value?.asPromptContext() ?: "No accessibility screen snapshot. Enable the service and open an app."

        fun isConnected(): Boolean = instance != null
    }
}
