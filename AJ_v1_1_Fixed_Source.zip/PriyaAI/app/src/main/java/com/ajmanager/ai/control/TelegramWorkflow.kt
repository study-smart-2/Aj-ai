package com.ajmanager.ai.control

enum class TelegramWorkflow(val label: String, val instruction: String) {
    GENERAL("General task", ""),
    FIND_CHAT("Find chat", "In Telegram, find the chat named: "),
    DRAFT_MESSAGE("Draft message", "Open the specified Telegram chat and prepare this message, but do not send it: "),
    FORWARD_MESSAGE("Forward message", "Forward the message I identify to this destination. Ask me to select the exact message if it is not clearly visible: "),
    CHANNEL_POST("Channel post", "Prepare this post in the specified Telegram channel. Do not publish until I approve: "),
    SEND_MEDIA("Send media", "Open the specified Telegram chat and guide the media picker to the file I specify. Do not send until I approve: "),
    SAVE_MEDIA("Save media", "Save the currently selected Telegram media to the device only if the visible menu offers that action: "),
    OPEN_BOT("Open bot", "Find and open this Telegram bot: "),
    OPEN_MINI_APP("Open Mini App", "Open the Mini App associated with the visible bot or chat. Do not submit forms or make purchases: "),
    SEARCH_MESSAGES("Search messages", "Search within the current Telegram chat for: ");

    fun command(detail: String): String =
        if (instruction.isBlank()) detail.trim() else instruction + detail.trim()
}
